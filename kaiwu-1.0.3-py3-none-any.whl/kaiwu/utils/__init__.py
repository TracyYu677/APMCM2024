"""
工具集合
"""
from kaiwu.utils._logger import set_log_level

__all__ = ["set_log_level"]
