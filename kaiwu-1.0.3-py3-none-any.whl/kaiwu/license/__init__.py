"""
license相关
"""
from kaiwu.license._license_utils import init

__all__ = ["init"]
