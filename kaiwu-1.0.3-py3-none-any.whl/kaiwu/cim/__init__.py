# -*- coding: utf-8 -*-
"""
模块: cim

功能: 提供一系列CIM求解相关的接口
"""
from kaiwu.cim._precision import calculate_ising_matrix_bit_width, adjust_ising_matrix_precision

__all__ = [
    "calculate_ising_matrix_bit_width", "adjust_ising_matrix_precision"
]
